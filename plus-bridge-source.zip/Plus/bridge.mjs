import { createChatGPT } from './devkit/dist/index.js';
import { createEncryption } from './encryption.mjs';
import { createServer } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

process.umask(0o077);
const credentialDir = process.env.CREDENTIALS_DIRECTORY;
if (!credentialDir) throw new Error('Systemd credentials required');
const token = (await readFile(join(credentialDir, 'bridge-token'), 'utf8')).trim();
if (token.length < 32) throw new Error('Bridge token required');
const client = createChatGPT({ appName: '轻衡 LightBalance', appId: 'lightbalance',
  redirectPort: 0, sendHostId: true, storageDir: process.env.PLUS_STORAGE_DIR,
  credentialEncryption: createEncryption(),
  openBrowser() { throw new Error('Remote sign-in must be completed on Mac'); }
});
function reply(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(value));
}
let busy = false;
const server = createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return reply(res, 200, { ok: true });
  const actual = Buffer.from(req.headers.authorization || '');
  const expected = Buffer.from('Bearer ' + token);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return reply(res, 401, { error: 'Unauthorized' });
  if (busy) return reply(res, 429, { error: { code: 'bridge_busy' } });
  busy = true;
  try {
    const session = await client.getSession();
    if (!session.sharing) return reply(res, 403, { error: { code: 'subscription_not_authorized' } });
    if (req.method === 'GET' && req.url === '/models') {
      return reply(res, 200, { models: await client.listModels() });
    }
    if (req.method !== 'POST' || req.url !== '/responses') return reply(res, 404, { error: 'Not found' });
    let size = 0;
    const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 5 * 1024 * 1024) return reply(res, 413, { error: 'Body too large' });
      chunks.push(chunk);
    }
    const payload = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    const { model, input, instructions, text } = payload;
    if (typeof model !== 'string' || !Array.isArray(input) || typeof instructions !== 'string') return reply(res, 400, { error: 'Invalid payload' });
    // Forward only these fields. The SDK forces stream=true and store=false.
    const result = await client.streamResponse({ model, input, instructions, text,
      signal: AbortSignal.timeout(180000) });
    return reply(res, 200, { status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: result.text }] }] });
  } catch (error) {
    const status = error.status && error.status >= 400 && error.status <= 599 ? error.status : 502;
    reply(res, status, { error: { code: error.code || 'bridge_failed', request_id: error.requestId } });
  } finally { busy = false; }
});
server.requestTimeout = 200000;
server.headersTimeout = 15000;
server.listen(8788, '127.0.0.1', () => console.log('Plus bridge ready on loopback.'));
