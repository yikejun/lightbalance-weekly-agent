import Foundation
import Security

// Output is consumed only by the trusted Node process, never sent to the UI.
let query: [String: Any] = [
    kSecClass as String: kSecClassGenericPassword,
    kSecAttrService as String: "LightBalance.ChatGPT.SDK.encryption",
    kSecAttrAccount as String: "installation",
    kSecReturnData as String: true,
    kSecMatchLimit as String: kSecMatchLimitOne
]
var found: CFTypeRef?
var status = SecItemCopyMatching(query as CFDictionary, &found)
if status == errSecItemNotFound {
    var bytes = [UInt8](repeating: 0, count: 32)
    guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else { exit(2) }
    let data = Data(bytes)
    let item: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: "LightBalance.ChatGPT.SDK.encryption",
        kSecAttrAccount as String: "installation",
        kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
        kSecValueData as String: data
    ]
    status = SecItemAdd(item as CFDictionary, nil)
    guard status == errSecSuccess || status == errSecDuplicateItem else { exit(3) }
    status = SecItemCopyMatching(query as CFDictionary, &found)
}
guard status == errSecSuccess, let data = found as? Data, data.count == 32 else { exit(4) }
FileHandle.standardOutput.write(data.base64EncodedData())
