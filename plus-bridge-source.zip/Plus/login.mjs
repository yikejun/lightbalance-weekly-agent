import { createChatGPT } from './devkit/dist/index.js';
import { createEncryption } from './encryption.mjs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const run = promisify(execFile);
const here = dirname(fileURLToPath(import.meta.url));
process.umask(0o077);
if (process.platform !== 'darwin') throw new Error('本机授权工具需要在 Mac 运行。');
const encryption = createEncryption();
const chatgpt = createChatGPT({
  appName: '轻衡 LightBalance', appId: 'lightbalance',
  redirectPort: 0, storageDir: join(here, 'runtime'),
  credentialEncryption: encryption, sendHostId: true,
  async openBrowser(url) {
    const target = new URL(url);
    if (target.origin !== 'https://auth.openai.com') throw new Error('Unexpected auth origin');
    console.log('已打开官方登录页。请在浏览器完成登录、选择账户并确认应用授权。');
    await run('/usr/bin/open', [target.href]);
  }
});

function safeSession(session) {
  return { status: session.status, sharing: session.sharing,
    ...(session.error ? { error: { code: session.error.code, status: session.error.status } } : {}) };
}
try {
  const command = process.argv[2] || 'status';
  if (command === 'storage-check') {
    if (!await encryption.isAvailable()) throw new Error('Keychain unavailable');
    const value = encryption.encrypt('storage-check');
    if (encryption.decrypt(value) !== 'storage-check') throw new Error('Encryption failed');
    console.log('钥匙串加密存储检查通过。');
  } else if (command === 'login') {
    const session = await chatgpt.signIn({ signal: AbortSignal.timeout(10 * 60 * 1000) });
    console.log(JSON.stringify(safeSession(session)));
    console.log(session.sharing ? '已获得 Plus 使用权限，尚未进行模型调用。' : '尚未获得 Plus 使用权限，不能开始识别。');
  } else if (command === 'status') {
    console.log(JSON.stringify(safeSession(await chatgpt.getSession())));
  } else if (command === 'verify') {
    const session = await chatgpt.getSession();
    if (!session.sharing) throw new Error('请先完成授权并允许应用使用 ChatGPT 订阅。');
    const models = await chatgpt.listModels();
    console.log(JSON.stringify({ models: models.map(m => ({ slug: m.slug, name: m.displayName })) }));
    if (!models.length) throw new Error('账户未返回可用模型。');
    const result = await chatgpt.streamResponse({ model: models[0].slug, input: 'Reply with exactly: Token sharing works.' });
    if (!result.text.trim()) throw new Error('模型未返回内容。');
    console.log('实际文字调用已完成。尚未验证图片、云端或授权续期。');
  } else throw new Error('Unknown command');
} catch (error) {
  // Do not log raw upstream messages, tokens, callback URLs or identity.
  console.error(JSON.stringify({ ok: false, code: error.code || 'local_setup_failed',
    status: error.status, requestId: error.requestId }));
  process.exitCode = 1;
}
