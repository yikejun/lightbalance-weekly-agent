import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const run = promisify(execFile);
const here = dirname(fileURLToPath(import.meta.url));
export function createEncryption() {
  let key;
  return {
    id: process.platform === 'darwin' ? 'lightbalance-macos-keychain-aes256gcm-v1' : 'lightbalance-systemd-aes256gcm-v1',
    async isAvailable() {
      try {
        if (process.platform === 'darwin') {
          const { stdout } = await run(join(here, 'keychain-helper'), [], { timeout: 30000 });
          key = Buffer.from(stdout.trim(), 'base64');
        } else {
          if (!process.env.CREDENTIALS_DIRECTORY) return false;
          key = await readFile(join(process.env.CREDENTIALS_DIRECTORY, 'plus-storage-key'));
        }
        return key.length === 32;
      } catch { return false; }
    },
    encrypt(plaintext) {
      const nonce = randomBytes(12);
      const cipher = createCipheriv('aes-256-gcm', key, nonce);
      const body = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
      return Buffer.concat([nonce, cipher.getAuthTag(), body]);
    },
    decrypt(ciphertext) {
      const data = Buffer.from(ciphertext);
      if (data.length < 28) throw new Error('Invalid encrypted record');
      const cipher = createDecipheriv('aes-256-gcm', key, data.subarray(0, 12));
      cipher.setAuthTag(data.subarray(12, 28));
      return Buffer.concat([cipher.update(data.subarray(28)), cipher.final()]).toString('utf8');
    }
  };
}
